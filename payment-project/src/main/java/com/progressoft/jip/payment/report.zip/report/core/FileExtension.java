package com.progressoft.jip.payment.report.core;

public enum FileExtension {
	CSV, XML
}
