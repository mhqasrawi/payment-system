package com.progressoft.jip.payment.report.core;

public interface ReportNode<T> {

	String getName();

	T getValue();

}