package com.progressoft.jip.payment.report.core;

public interface ReportManager {

	void generateReport(ReportSettings settings);	
}
